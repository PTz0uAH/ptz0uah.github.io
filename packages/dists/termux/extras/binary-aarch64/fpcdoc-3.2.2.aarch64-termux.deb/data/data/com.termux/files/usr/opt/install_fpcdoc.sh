#!/data/data/com.termux/files/usr/bin/sh

# this is the installation script for FPC-3.2.2. documentation (txt) distri

FPCDISTRI=fpc-3.2.2.aarch64-termux
FPCDOCS=fpcdoc-3.2.2.aarch64-termux.tar.gz
FPCTARGZ=$FPCDOCS
FPCUNPACK="tar -xf $FPCTARGZ"

export FPCDIR=$PREFIX/opt/$FPCDISTRI

# the deb file unpacks the archive to the opt location
# including this install_fpcdoc.sh script

# unpack if dir not exists
echo "unpack fpcdoc archive $FPCTARGZ"
test -d "$PREFIX/opt/$FPCDISTRI/doc" && echo already exists, skipping.. || $FPCUNPACK

# note: if you uninstall the deb-file to save space the fpcdoc-dir is kept!
# to remove the physical fpcdoc installation use rm -rf $OPT/$FPCDISTRI/doc
#
# I guess it needs a real maintainer to make it work according to Termux (official) standards
# but this is a start.. now any pascal dev can find the elaborate documentation..and start coding..
# and remember.. Termux prefers single achitecture so contemplating on that it was
# for practical reasons Freepascal "Termuxified" resides in a single directory..
# now I can have multiple FPC versions orderly in $PREFIX/opt/ if needed.. "oldskool ;-)"
# PLUS keeping the "FPC from trunk"-build intact.. because that is where the pioneering continues..
#
# Anyway.. have fun with FreePascal on Android..
#
# PTz()uAH
#
# ergo: Nothing was cross compiled.. all distri-debs were produced on-device..
